/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author Devan
 */
public class Client extends JFrame{
    private JTextField userText; // The area for u sending messages
    private JTextArea chatWindow; //the area for to display messages
    private ObjectOutputStream output;  // U sending data obj
    private ObjectInputStream input;   // u receiving data obj
    private final String message = "";
    private final String serverIP;
    private Socket connection;  // the actual server
    private  String nameOfClient; // Actual suppose to be the server's name... I was too lazy to rename it thou
    //Constructor
    public Client(String theHost, String ServerName){
        super("Client!");
        serverIP = theHost;
        userText = new JTextField();
        userText.setEditable(false);
        userText.addActionListener((ActionEvent eve) -> {
            sendMessage(eve.getActionCommand());
            userText.setText("");
        });
        userText.setForeground(Color.red);
        add(userText,BorderLayout.NORTH);
        chatWindow = new JTextArea();
        add(new JScrollPane(chatWindow),BorderLayout.CENTER);
        setSize(500,400);
        setVisible(true);
        
        chatWindow.addFocusListener(new FocusListener()
        {
         @Override
         public void focusGained(FocusEvent fe)
        {
           chatWindow.setForeground(Color.green);
        }

         @Override
        public void focusLost(FocusEvent fe)
        {
            chatWindow.setForeground(Color.green);
        }
        });
        
        this.nameOfClient = ServerName;
    }

  
    
    public void startRunning(){
        try{
            connectToSever();
            setupStreams();
            whileChatting();
        }
        catch(EOFException exp){
            showMessage("\n Client terminated connection");
        }
        catch(IOException exp){
            exp.printStackTrace();
        }
        finally{
            closeCrap();
        }
    }

    private void connectToSever()throws IOException {
       showMessage("Attempting connection");
       connection = new Socket(InetAddress.getByName(serverIP), 2017);
       showMessage("Connected to: " + connection.getInetAddress().getHostName());  
    }
    
     private void setupStreams() throws IOException 
     {
       output = new ObjectOutputStream(connection.getOutputStream());
       output.flush();
       
       input = new ObjectInputStream(connection.getInputStream());
       showMessage("\n\nStreams have been set up\n");
    }
     // close streams and sockets after you're done chatting
    private void closeCrap()
    {
       showMessage("\n Closing connection down... \n");
       ableToType(false);
       try
       {
           output.close();
           input.close();
           connection.close();
       }
       catch(IOException exp)
       {
           exp.printStackTrace();
       }
    }
    
    private void ableToType(final boolean status) {
           SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
               userText.setEditable(status);
            }
        });
    }
    
    private void whileChatting() throws IOException 
    {
        String message = "You are now connected";
        sendMessage(message);
        ableToType(true);
        do{
            // have a convo
            try{
                message = (String) input.readObject();
                showMessage("\n\t\t\t"+ message);
            }
            catch(ClassNotFoundException exp){
                showMessage("\n IDK wtf that user sent");
            }
        }
        while(!message.equals(nameOfClient+" - END"));
    }
    private void sendMessage(String message) {
       try{
           output.writeObject(nameOfClient+"- " + message);
           output.flush();
           showMessage( "\n"+nameOfClient+"- "+ message);
       }
       catch(IOException exp){
           chatWindow.append("\n Error: Dude I can't send that message, something fucked up!");
       }
    }
    
    
    //Updates chatWindow
    private void showMessage(final String message) {
        SwingUtilities.invokeLater(new Runnable() {
          
            public void run() {
                chatWindow.append(message);
            }
        });
    }
}
