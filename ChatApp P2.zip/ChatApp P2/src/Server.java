
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Devan
 */
public class Server extends JFrame{
    private JTextField userText; // The area for u sending messages
    private JTextArea chatWindow; //the area for to display messages
    private ObjectOutputStream output;  // U sending data obj
    private ObjectInputStream input;   // u receiving data obj
    private ServerSocket server;    // the server connection socket
    private Socket connection;  // the actual server
    private String nameOfServer;
    
    
    
    public Server(String nameOfClient) {
        super("MiGo's Instant Messenger");
        
        userText = new JTextField();
        userText.setEditable(false);
        userText.addActionListener((ActionEvent event) -> {
            sendMessage(event.getActionCommand());
            userText.setText("");
        });
        add(userText, BorderLayout.NORTH);
        userText.setForeground(Color.green);
        chatWindow = new JTextArea();
        chatWindow.setCaretColor(Color.green);
        
        chatWindow.addFocusListener(new FocusListener()
        {
         @Override
         public void focusGained(FocusEvent fe)
        {
            //chatWindow.setForeground(Color.red);
        }

         @Override
        public void focusLost(FocusEvent fe)
        {
            chatWindow.setForeground(Color.red);
        }
        });
        
        add(new JScrollPane(chatWindow));
        setSize(500,400);
        setVisible(true);
        this.nameOfServer = nameOfClient;
    }
    // set up and run server
    
    public void StartRunning(){
        try{
            server = new ServerSocket(2017);
            while(true)
            {
                
                try
                {
                    WaitforConnection();
                    setupStreams();  // Also know as the path ways of connections
                    whileChatting();
                }
                catch (EOFException eofExc)
                {
                    showMessage("\n Server end the connection");
                }
                finally
                {
                    closeCrap();
                }
            }
        }
        catch(IOException ioExc){
            ioExc.printStackTrace();
        }
    }
   // wait for connection, then display connection info
    private void WaitforConnection() throws IOException
    {
       showMessage("waiting for someone to connect... \n");
       connection = server.accept();
       showMessage(" Now connected to: "+ connection.getInetAddress().getHostName());
    }
   // get stream to send and receive data
    private void setupStreams() throws IOException {
       output = new ObjectOutputStream(connection.getOutputStream());
       output.flush();
       
       input = new ObjectInputStream(connection.getInputStream());
       showMessage("\n\nStreams have been set up\n");
    }

    private void whileChatting() throws IOException {
        String message = "You are now connected";
        sendMessage(message);
        ableToType(true);
        do{
            // have a convo
            try{
                message = (String) input.readObject();
                showMessage("\n\t\t\t"+ message);
            }
            catch(ClassNotFoundException exp){
                showMessage("\n IDK wtf that user sent");
            }
        }
        while(!message.equals(nameOfServer+" - END"));
    }

    //Updates chatWindow
    private void showMessage(final String message) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                chatWindow.append(message);
            }
        });
    }

    // close streams and sockets after you're done chatting
    private void closeCrap() {
       showMessage("\n Closing connection... \n");
       ableToType(false);
       try{
           output.close();
           input.close();
           connection.close();
       }
       catch(IOException exp){
           exp.printStackTrace();
       }
    }

    private void ableToType(final boolean status) {
           SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
               userText.setEditable(status);
            }
        });
    }

    private void sendMessage(String message) {
       try{
           output.writeObject(nameOfServer+" - " + message);
           output.flush();
           showMessage("\n"+nameOfServer+" - "+ message);
       }
       catch(IOException exp){
           chatWindow.append("\n Error: Dude I can't send that message");
       }
    }


}
